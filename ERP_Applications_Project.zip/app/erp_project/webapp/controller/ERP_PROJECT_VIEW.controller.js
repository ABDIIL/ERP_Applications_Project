sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("my.project.erpproject.controller.ERP_PROJECT_VIEW", {
        onInit() {
        }
    });
});